// import { useContext, useState } from "react";
// import { Link } from "react-router-dom";
// import { AuthContext } from "../context/AuthContext";
// import List from "../components/Dashboard/List";
// import axios from "axios";
// import { useNavigate } from "react-router-dom";
// import "../style/dash.css";
// import icon from "../assets/icon.png"; 
// import Static from "../components/Static";

// const Dashboard = () => {
//   const { authToken, setAuthToken } = useContext(AuthContext);
//   const navigate = useNavigate();
//   const [searchTerm, setSearchTerm] = useState("");
//   const [isDialogOpen, setIsDialogOpen] = useState(false); // Dialog state
//   const [listName, setListName] = useState("");
//   const [isPublic, setIsPublic] = useState(false);

//   const handleLogout = async () => {
//     try {
//       await axios.get("http://localhost:8000/auth/logout", {
//         headers: { Authorization: `Bearer ${authToken}` },
//       });

//       setAuthToken(null);
//       localStorage.removeItem("authToken");
//       navigate("/");
//     } catch (err) {
//       console.error("Logout failed", err.response?.data || err.message);
//     }
//   };

//   const handleSearchSubmit = (e) => {
//     e.preventDefault();
//     if (searchTerm.trim()) {
//       navigate(`/search?title=${searchTerm}`);
//     }
//   };

//   const handleCreateList = async () => {
//     if (!listName.trim()) return alert("List name cannot be empty!");

//     try {
//       const response = await axios.post(
//         "http://localhost:8000/lists/create",
//         { name: listName, isPublic },
//         {
//           headers: { Authorization: `Bearer ${authToken}` },
//         }
//       );
//       alert(response.data.message || "List created successfully!");
//       setListName("");
//       setIsPublic(false);
//       setIsDialogOpen(false); // Close dialog after success
//       window.location.reload();
//     } catch (err) {
//       console.error(err.response?.data || err.message);
//       alert("Failed to create the list.");
//     }
//   };

//   if (!authToken) {
//     return (
//       <div className="dashboard-container">
//         <p className="auth-message">Please log in to access the dashboard.</p>
//       </div>
//     );
//   }

//   return (
//     <div className="dashboard-container">
//       {/* Navbar */}
//       <nav className="navbar">
//         <div className="navbar-left">
//           <h2 className="navbar-heading">MovieX
//           </h2>
//           <div className="centre">
//           <Link to='/dashboard' className="home-button"> Home</Link>
//             <Link to='/about' className="home-button"> About</Link>
//             <Link to='/contact' className="home-button"> ContactUs</Link>
//             <button className="create" onClick={() => setIsDialogOpen(true)}>
//             Create List
//           </button>
//           </div>
          
//         </div>
     
//         <div className="searching">
//             <form onSubmit={handleSearchSubmit}>
//               <input
//                 type="text"
//                 placeholder="Search movies..."
//                 className="search-bar"
//                 value={searchTerm}
//                 onChange={(e) => setSearchTerm(e.target.value)}
//               />
//               <span className="im">
//                 <img
//                   src={icon}
//                   alt="Search Icon"
//                   className="navbar-icon"
//                   onClick={handleSearchSubmit}
//                 />
//               </span>
//             </form>
//           </div>
//           <button onClick={handleLogout} className="logout-button">
//             Logout
//           </button>
//       </nav>

//       {/* Dialog Box */}
//       {isDialogOpen && (
//         <div className="dialog-backdrop">
//           <div className="dialog-box">
//             <h3>Create a New List</h3>
//             <input
//               type="text"
//               placeholder="Enter list name"
//               className="list-name-input"
//               value={listName}
//               onChange={(e) => setListName(e.target.value)}
//             />
//             <label className="public-toggle">
//               <input
//                 type="checkbox"
//                 checked={isPublic}
//                 onChange={(e) => setIsPublic(e.target.checked)}
//               />
//               Public
//             </label>
//             <div className="dialog-actions">
//               <button className="create" onClick={handleCreateList}>
//                 Create
//               </button>
//               <button className="cancel" onClick={() => setIsDialogOpen(false)}>
//                 Cancel
//               </button>
//             </div>
//           </div>
//         </div>
//       )}

//       {/* Main Content: List */}
//       <div className="list-section">
//         <List token={authToken} searchTerm={searchTerm} />
//       </div>
//       <Static />
//     </div>
//   );
// };

// export default Dashboard;




import { useContext, useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import List from "../components/Dashboard/List";
import axios from "axios";
import "../style/dash.css";
import "../style/static.css";
import icon from "../assets/icon.png"; 

const Dashboard = () => {
  const { authToken, setAuthToken } = useContext(AuthContext);
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false); 
  const [listName, setListName] = useState("");
  const [isPublic, setIsPublic] = useState(false);
  const [genres, setGenres] = useState([]);
  const [countries, setCountries] = useState([]);
  const [selectedGenre, setSelectedGenre] = useState("");
  const [selectedCountry, setSelectedCountry] = useState("");
  // const [filteredMovies, setFilteredMovies] = useState([]);
   // ✅ Weather-Based Movies State
   const [lat, setLat] = useState(null);
   const [lon, setLon] = useState(null);
   const [weatherMovies, setWeatherMovies] = useState([]);
   const [locationPermission, setLocationPermission] = useState(null);

  // ✅ Fetch Genres & Countries from TMDB
  useEffect(() => {
    const fetchGenres = async () => {
      try {
        const response = await axios.get("http://localhost:8000/movies/genres", {
          headers: { Authorization: `Bearer ${authToken}` },
        });
        setGenres(response.data);
      } catch (err) {
        console.error("Failed to fetch genres:", err);
      }
    };

    const fetchCountries = async () => {
      try {
        const response = await axios.get("http://localhost:8000/movies/countries", {
          headers: { Authorization: `Bearer ${authToken}` },
        });
        setCountries(response.data);
      } catch (err) {
        console.error("Failed to fetch countries:", err);
      }
    };

    fetchGenres();
    fetchCountries();
  }, []);


  useEffect(() => {
    console.log("location le rh h")
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLat(position.coords.latitude);
          setLon(position.coords.longitude);
          setLocationPermission("granted");
          console.log("User Location:", position.coords.latitude, position.coords.longitude);
        },
        (error) => {
          console.error("Error getting location:", error);
          setLocationPermission("denied");
        }
      );
    } else {
      console.error("Geolocation is not supported by this browser.");
      setLocationPermission("not_supported");
    }
  }, []);

  useEffect(() => {
    if (lat && lon) {
      const fetchWeatherMovies = async () => {
        try {
          const response = await axios.get(`http://localhost:8000/movies/weather?lat=${lat}&lon=${lon}`, {
            headers: { Authorization: `Bearer ${authToken}` },
          });
          setWeatherMovies(response.data.movies);
        } catch (err) {
          console.error("Failed to fetch weather-based movies:", err);
        }
      };

      fetchWeatherMovies();
    }
  }, [lat, lon]);


  // ✅ Fetch Movies Based on Selected Genre & Country
  useEffect(() => {
    console.log("Fetching movies for Genre:", selectedGenre || "Not Selected", "Country:", selectedCountry || "Not Selected");

    // if (selectedGenre || selectedCountry) {
    //   const fetchFilteredMovies = async () => {
    //     try {
    //       let apiUrl = `http://localhost:8000/movies/filter?`;
          
    //       if (selectedGenre) {
    //         apiUrl += `genre=${selectedGenre}&`;
    //       }
    //       if (selectedCountry) {
    //         apiUrl += `country=${selectedCountry}`;
    //       }

    //       console.log("Sending API Request to:", apiUrl);

    //       const response = await axios.get(apiUrl, {
    //         headers: { Authorization: `Bearer ${authToken}` },
    //       });
    //       console.log("Filtered Movies Response:", response.data);
    //       setFilteredMovies(response.data);
    //     } catch (err) {
    //       console.error("Failed to fetch filtered movies:", err);
    //     }
    //   };

    //   fetchFilteredMovies();
    if (selectedGenre || selectedCountry) {
      let queryParams = "";
      if (selectedGenre) queryParams += `genre=${selectedGenre}&`;
      if (selectedCountry) queryParams += `country=${selectedCountry}`;
  
      navigate(`/filtered-movies?${queryParams}`);
    }
    
  }, [selectedGenre, selectedCountry]);



  const handleLogout = async () => {
    try {
      await axios.get("http://localhost:8000/auth/logout", {
        headers: { Authorization: `Bearer ${authToken}` },
      });

      setAuthToken(null);
      localStorage.removeItem("authToken");
      navigate("/");
    } catch (err) {
      console.error("Logout failed", err.response?.data || err.message);
    }
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      navigate(`/search?title=${searchTerm}`);
    }
  };

  const handleCreateList = async () => {
    if (!listName.trim()) return alert("List name cannot be empty!");

    try {
      const response = await axios.post(
        "http://localhost:8000/lists/create",
        { name: listName, isPublic },
        {
          headers: { Authorization: `Bearer ${authToken}` },
        }
      );
      alert(response.data.message || "List created successfully!");
      setListName("");
      setIsPublic(false);
      setIsDialogOpen(false);
      window.location.reload();
    } catch (err) {
      console.error(err.response?.data || err.message);
      alert("Failed to create the list.");
    }
  };

  if (!authToken) {
    return (
      <div className="dashboard-container">
        <p className="auth-message">Please log in to access the dashboard.</p>
      </div>
    );
  }

  return (
    <div className="dashboard-container">
      {/* ✅ Navbar */}
      <nav className="navbar">
        <div className="navbar-left">
          <h2 className="navbar-heading">MovieX</h2>

          <div className="centre">
            <Link to='/dashboard' className="home-button"> Home</Link>
            <Link to='/about' className="home-button"> About</Link>
            <Link to='/contact' className="home-button"> Contact Us</Link>
            <button className="create" onClick={() => setIsDialogOpen(true)}>
              Create List
            </button>
          </div>
        </div>

          {/* ✅ Genre Dropdown */}
          <select value={selectedGenre || ""} onChange={(e) => setSelectedGenre(e.target.value)} className="dropdown">
          <option value="" className="">Genre</option>
          {genres.map((genre) => (
            <option key={genre.id} value={genre.id}>{genre.name}</option>
          ))}
        </select>

        {/* ✅ Country Dropdown */}
        <select value={selectedCountry || ""} onChange={(e) => setSelectedCountry(e.target.value)} className="dropdown">
          <option value="" className="">Country</option>
          {countries.map((country) => (
            <option key={country.iso_3166_1} value={country.iso_3166_1}>{country.english_name}</option>
          ))}
        </select>

        {/* ✅ Search Bar */}
        <div className="searching">
          <form onSubmit={handleSearchSubmit}>
            <input
              type="text"
              placeholder="Search movies..."
              className="search-bar"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <span className="im" onClick={handleSearchSubmit}>
              <img src={icon} alt="Search Icon" className="navbar-icon" />
            </span>
          </form>
        </div>

        {/* ✅ Logout Button */}
        <button onClick={handleLogout} className="logout-button">
          Logout
        </button>
      </nav>

      {/* ✅ Dialog Box */}
      {isDialogOpen && (
        <div className="dialog-backdrop">
          <div className="dialog-box">
            <h3>Create a New List</h3>
            <input
              type="text"
              placeholder="Enter list name"
              className="list-name-input"
              value={listName}
              onChange={(e) => setListName(e.target.value)}
            />
            <label className="public-toggle">
              <input
                type="checkbox"
                checked={isPublic}
                onChange={(e) => setIsPublic(e.target.checked)}
              />
              Public
            </label>
            <div className="dialog-actions">
              <button className="create" onClick={handleCreateList}>
                Create
              </button>
              <button className="cancel" onClick={() => setIsDialogOpen(false)}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
         {/* ✅ Lists & Static Section */}
         <div className="list-section">
        <List token={authToken} searchTerm={searchTerm} />
      </div>
       {/* ✅ Weather-Based Movies Section */}
       {weatherMovies.length > 0 && (
          <div className="category-section">
          <h4>Movies Recommended for current Weather</h4>
          <div className="movie-grid">
            {weatherMovies.map((movie) => (
              <div key={movie.id} className="movie-ca">
                <img className="movie-poster" src={movie.poster_path ? `https://image.tmdb.org/t/p/w500${movie.poster_path}` : icon} alt={movie.title} />
                <h3>{movie.title}</h3>
                <p>{movie.release_date ? movie.release_date.split('-')[0] : "N/A"}</p>
              </div>
            ))}
          </div>
        </div>
      )}
        
   
    
    </div>
  );
};

export default Dashboard;
