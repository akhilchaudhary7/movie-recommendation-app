import { useContext, useEffect, useState } from "react";
import { useLocation, useNavigate, Link } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import axios from "axios";
import "../style/filtered.css"; // ✅ Styling
import icon from "../assets/icon.png";

const FilteredMovies = () => {
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const genre = queryParams.get("genre");
  const country = queryParams.get("country");

  const { authToken, setAuthToken } = useContext(AuthContext);
  const [movies, setMovies] = useState([]);
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [listName, setListName] = useState("");
  const [isPublic, setIsPublic] = useState(false);
  const [genres, setGenres] = useState([]);
  const [countries, setCountries] = useState([]);
  const [selectedGenre, setSelectedGenre] = useState(genre || "");
  const [selectedCountry, setSelectedCountry] = useState(country || "");
  const [userLists, setUserLists] = useState([]);
  const [selectedList, setSelectedList] = useState({});
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchGenres = async () => {
      try {
        const response = await axios.get("http://localhost:8000/movies/genres", {
          headers: { Authorization: `Bearer ${authToken}` },
        });
        setGenres(response.data);
      } catch (err) {
        console.error("Failed to fetch genres:", err);
      }
    };

    const fetchCountries = async () => {
      try {
        const response = await axios.get("http://localhost:8000/movies/countries", {
          headers: { Authorization: `Bearer ${authToken}` },
        });
        setCountries(response.data);
      } catch (err) {
        console.error("Failed to fetch countries:", err);
      }
    };

    fetchGenres();
    fetchCountries();
  }, [authToken]);

  useEffect(() => {
    const fetchMovies = async () => {
      try {
        let apiUrl = `http://localhost:8000/movies/filter?`;
        if (selectedGenre) apiUrl += `genre=${selectedGenre}&`;
        if (selectedCountry) apiUrl += `country=${selectedCountry}`;

        console.log("Fetching filtered movies from:", apiUrl);
        const response = await axios.get(apiUrl, {
          headers: { Authorization: `Bearer ${authToken}` },
        });
        setMovies(response.data);
      } catch (err) {
        console.error("Failed to fetch filtered movies:", err);
      }
    };

    fetchMovies();
  }, [selectedGenre, selectedCountry, authToken]);

  useEffect(() => {
    const fetchUserLists = async () => {
      try {
        const response = await axios.get("http://localhost:8000/lists/getLists", {
          headers: { Authorization: `Bearer ${authToken}` },
        });
        setUserLists(response.data);
      } catch (err) {
        console.error("Failed to fetch user lists:", err);
        setError("Failed to fetch lists. Please try again later.");
      }
    };

    if (authToken) fetchUserLists();
  }, [authToken]);

  const handleFilterChange = (genre, country) => {
    setSelectedGenre(genre);
    setSelectedCountry(country);
    let queryParams = "";
    if (genre) queryParams += `genre=${genre}&`;
    if (country) queryParams += `country=${country}`;
    navigate(`/filtered-movies?${queryParams}`);
  };

  const handleLogout = async () => {
    try {
      await axios.get("http://localhost:8000/auth/logout", {
        headers: { Authorization: `Bearer ${authToken}` },
      });

      setAuthToken(null);
      localStorage.removeItem("authToken");
      navigate("/");
    } catch (err) {
      console.error("Logout failed", err.response?.data || err.message);
    }
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      navigate(`/search?title=${searchTerm}`);
    }
  };

  const handleAddToList = async (movieId, listId) => {
    try {
      await axios.post(
        "http://localhost:8000/lists/add",
        { listId, movieId },
        {
          headers: { Authorization: `Bearer ${authToken}` },
        }
      );
      navigate(`/lists/${listId}`);
    } catch (err) {
      console.error(err);
      setError("Failed to add movie to list. Please try again.");
    }
  };

  const handleCreateList = async () => {
    if (!listName.trim()) return alert("List name cannot be empty!");

    try {
      const response = await axios.post(
        "http://localhost:8000/lists/create",
        { name: listName, isPublic },
        {
          headers: { Authorization: `Bearer ${authToken}` },
        }
      );
      alert(response.data.message || "List created successfully!");
      setListName("");
      setIsPublic(false);
      setIsDialogOpen(false);
      window.location.reload();
    } catch (err) {
      console.error(err.response?.data || err.message);
      alert("Failed to create the list.");
    }
  };

  if (!authToken) {
    return (
      <div className="dashboard-container">
        <p className="auth-message">Please log in to access the dashboard.</p>
      </div>
    );
  }

  return (
    <div className="con">
      {/* Navbar */}
      <nav className="navbar">
        <div className="navbar-left">
          <h2 className="navbar-heading">MovieX</h2>
          <div className="centre">
            <Link to='/dashboard' className="home-button"> Home</Link>
            <Link to='/about' className="home-button"> About</Link>
            <Link to='/contact' className="home-button"> Contact Us</Link>
            <button className="create" onClick={() => setIsDialogOpen(true)}>Create List</button>
          </div>
        </div>

        {/* Genre Dropdown */}
        <select value={selectedGenre} onChange={(e) => handleFilterChange(e.target.value, selectedCountry)} className="dropdownn">
          <option value="">Genre</option>
          {genres.map((genre) => (
            <option key={genre.id} value={genre.id}>{genre.name}</option>
          ))}
        </select>

        {/* Country Dropdown */}
        <select value={selectedCountry} onChange={(e) => handleFilterChange(selectedGenre, e.target.value)} className="dropdownn">
          <option value="">Country</option>
          {countries.map((country) => (
            <option key={country.iso_3166_1} value={country.iso_3166_1}>{country.english_name}</option>
          ))}
        </select>

        {/* Search Bar */}
        <div className="searchingy">
          <form onSubmit={handleSearchSubmit}>
            <input
              type="text"
              placeholder="Search movies..."
              className="search-bar"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <span className="im" onClick={handleSearchSubmit}>
              <img src={icon} alt="Search Icon" className="navbar-icon" />
            </span>
          </form>
        </div>

        {/* Logout Button */}
        <button onClick={handleLogout} className="logout-button">Logout</button>
      </nav>

      {/* Dialog Box for Creating List */}
      {isDialogOpen && (
        <div className="dialog-backdrop">
          <div className="dialog-box">
            <h3>Create a New List</h3>
            <input
              type="text"
              placeholder="Enter list name"
              className="list-name-input"
              value={listName}
              onChange={(e) => setListName(e.target.value)}
            />
            <label className="public-toggle">
              <input
                type="checkbox"
                checked={isPublic}
                onChange={(e) => setIsPublic(e.target.checked)}
              />
              Public
            </label>
            <div className="dialog-actions">
              <button className="create" onClick={handleCreateList}>
                Create
              </button>
              <button className="cancel" onClick={() => setIsDialogOpen(false)}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Filtered Movies Section */}
      <div className="filtered-container">
        <h2>Filtered Movies {selectedGenre && `for Genre: ${selectedGenre}`} {selectedCountry && `in Country: ${selectedCountry}`}</h2>
        {error && <p className="error-message">{error}</p>}
        <div className="movies-grid">
          {movies.length > 0 ? (
            movies.map((movie) => (
              <div key={movie.id} className="movie-card">
                <img src={movie.poster_path ? `https://image.tmdb.org/t/p/w500${movie.poster_path}` : icon} alt={movie.title} />
                <h3>{movie.title}</h3>
                <p>{movie.release_date ? movie.release_date.split('-')[0] : "N/A"}</p>
                <div className="list-dropdown">
                  <select
                    value={selectedList[movie.id] || ""}
                    onChange={(e) =>
                      setSelectedList({
                        ...selectedList,
                        [movie.id]: e.target.value,
                      })
                    }
                  >
                    <option value="" disabled>
                      Select a list
                    </option>
                    {userLists.map((list) => (
                      <option key={list._id} value={list._id}>
                        {list.name}
                      </option>
                    ))}
                  </select>
                  <button
                    className="butt"
                    onClick={() => handleAddToList(movie.id, selectedList[movie.id])}
                    disabled={!selectedList[movie.id]}
                  >
                    Add to List
                  </button>
                </div>
              </div>
            ))
          ) : (
            <p>No movies found.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default FilteredMovies;