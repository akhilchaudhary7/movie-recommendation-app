
// const axios = require('axios');
// const MovieList = require('../models/MovieList');

// exports.searchMovies = async (req, res) => {
//     const { title } = req.query;
//     const userId = req.user.id;

//     if (!title) {
//         return res.render('movies/search', { movies: [], lists: [] });
//     }

//     try {
//         // Fetch the current user's lists (both public and private)
//         const userLists = await MovieList.find({ user: userId });

//         // Fetch public lists created by other users
//         const publicLists = await MovieList.find({ user: { $ne: userId }, isPublic: true });

//         // Combine both lists
//         const lists = [...userLists, ...publicLists];

//         const response = await axios.get(`http://www.omdbapi.com/?s=${title}&apikey=${process.env.OMDB_API_KEY}`);
//         const data = response.data;
//         if (data.Response === 'False') {
//             return res.json({ movies: [], lists });

//             // return res.render('movies/search', { movies: [], lists });
//         }
//         // res.render('movies/search', { movies: data.Search, lists });
//         res.json({ movies: data.Search, lists });
//     } catch (err) {
//         console.log(err);
//         res.status(500).send('Server error');
//     }
// };

const axios = require('axios');
const MovieList = require('../models/MovieList');

exports.searchMovies = async (req, res) => {
    const { title } = req.query;
    const userId = req.user.id; 

    if (!title) {
        return res.json({ movies: [], lists: [] });
    }
    try {
        // Fetch the current user's lists (both public and private)
        const userLists = await MovieList.find({ user: userId });
        const publicLists = await MovieList.find({ user: { $ne: userId }, isPublic: true });
        const lists = [...userLists, ...publicLists];

        // Fetch movies from TMDB API
        const response = await axios.get(`https://api.themoviedb.org/3/search/movie?query=${title}&api_key=${process.env.TMDB_API_KEY}`);
        const data = response.data;

        if (data.results.length === 0) {
            return res.json({ movies: [], lists });
        }

        res.json({ movies: data.results, lists });
    } catch (err) {
        console.log(err);
        res.status(500).send('Server error');
    }
};


exports.getGenres = async (req, res) => {
    try {
        const response = await fetch(`https://api.themoviedb.org/3/genre/movie/list?api_key=${process.env.TMDB_API_KEY}&language=en-US`);
        const data = await response.json();
        res.json(data.genres); // Send only genres array
    } catch (err) {
        console.error("Error fetching genres:", err);
        res.status(500).json({ error: "Failed to fetch genres" });
    }
};


exports.getCountries = async (req, res) => {
    try {
        const response = await fetch(`https://api.themoviedb.org/3/watch/providers/regions?api_key=${process.env.TMDB_API_KEY}`);
        const data = await response.json();
        res.json(data.results); // Send countries list
    } catch (err) {
        console.error("Error fetching countries:", err);
        res.status(500).json({ error: "Failed to fetch countries" });
    }
};



exports.filterMovies = async (req, res) => {
    const { genre, country } = req.query;
    
    console.log("Received Filter Request - Genre:", genre || "Not Selected", "Country:", country || "Not Selected");

    try {
        //  Base URL with API Key
        let apiUrl = `https://api.themoviedb.org/3/discover/movie?api_key=${process.env.TMDB_API_KEY}`;

        //  Genre filter (Agar genre selected hai toh add karo)
        if (genre) {
            apiUrl += `&with_genres=${genre}`;
        }

        //  Country filter (Agar country selected hai toh add karo)
        if (country) {
            apiUrl += `&with_origin_country=${country}`;
        }

        console.log("TMDB API Request URL:", apiUrl); 
        const response = await fetch(apiUrl);
        const data = await response.json();

        console.log("TMDB API Response:", data.results.length, "movies found."); 

        if (!data.results || data.results.length === 0) {
            return res.status(404).json({ error: "No movies found." });
        }

        res.json(data.results);
    } catch (err) {
        console.error("Error fetching filtered movies:", err);
        res.status(500).json({ error: "Failed to fetch movies" });
    }
};

const mapWeatherToGenre = (weatherCondition) => {
    const weatherGenreMap = {
        Clear: "12", //  Adventure
        Clouds: "35", //  Comedy
        Rain: "18", //  Drama
        Snow: "16", //  Animation
        Thunderstorm: "27", //  Horror
        Drizzle: "10749", //  Romance
        Mist: "9648", //  Mystery
    };
    return weatherGenreMap[weatherCondition];// || "28"; // Default: Action
};


exports.getWeatherMovies = async (req, res) => {
    console.log("Weather API Called");
    console.log("OpenWeather API Key:", process.env.OPENWEATHER_API_KEY); 
    if (!process.env.OPENWEATHER_API_KEY) {
        return res.status(500).json({ error: "OpenWeather API Key is missing" });
    }

    const { lat, lon } = req.query;

    if (!lat || !lon) {
        return res.status(400).json({ error: "Latitude and Longitude are required" });
    }

    try {
        //  Fetch Weather Data from OpenWeather API
        const weatherResponse = await axios.get(
            `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${process.env.OPENWEATHER_API_KEY}&units=metric`
        );
        console.log("Weather API Response:", weatherResponse.data);

        const weatherData = weatherResponse.data;
        const weatherCondition = weatherData.weather[0].main;
        const genre = mapWeatherToGenre(weatherCondition);
 
        console.log(`Weather: ${weatherCondition}, Mapped Genre: ${genre}`);

        //  Fetch Movies from TMDB API Based on Weather Genre
        const moviesResponse = await axios.get(
            `https://api.themoviedb.org/3/discover/movie?api_key=${process.env.TMDB_API_KEY}&with_genres=${genre}`
        );

        res.json({
            location: weatherData.name,
            weather: weatherCondition,
            temperature: weatherData.main.temp,
            movies: moviesResponse.data.results,
        });

    } catch (err) {
        console.error("Error fetching weather-based movies:", err);
        res.status(500).json({ error: "Failed to fetch weather-based movies" });
    }
};