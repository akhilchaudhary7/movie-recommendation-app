const express = require('express');
const { searchMovies ,getGenres, getCountries, filterMovies , getWeatherMovies} = require('../controllers/movieController');
const { getUserLists } = require('../controllers/listController');

const router = express.Router();

router.get('/home', getUserLists);
router.get('/search', searchMovies);


router.get('/genres', getGenres); // Fetch genres from TMDB
router.get('/countries', getCountries); // Fetch countries from TMDB
router.get('/filter', filterMovies); // Fetch filtered movies
router.get('/weather', getWeatherMovies); // Fetch weather movies

module.exports = router;
